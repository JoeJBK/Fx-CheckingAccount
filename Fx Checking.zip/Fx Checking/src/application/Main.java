package application;

import javafx.application.Application;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;

public class Main extends Application {
	private Scene scene1;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void start(Stage mainStage) {
		CheckingBase cb = new CheckingBase();

		// Scene 1 - Login
		mainStage.setTitle("Checking");

		// Borderpane
		BorderPane borderP = new BorderPane();
		borderP.setPadding(new Insets(10, 50, 50, 50));

		// HBox
		HBox hbox = new HBox();
		hbox.setPadding(new Insets(20, 20, 20, 30));

		// Gridpane
		GridPane gridP = new GridPane();
		gridP.setPadding(new Insets(20, 20, 20, 20));
		gridP.setHgap(5);
		gridP.setVgap(5);

		// Implmenting
		Label labelUser = new Label("Username: ");
		Button loginBtn = new Button("Login");

		final Label loginMsg = new Label();
		TextField textUser = new TextField();

		// Gridpane Adding
		gridP.add(labelUser, 0, 0);
		gridP.add(textUser, 1, 0);

		gridP.add(loginBtn, 1, 1);
		gridP.add(loginMsg, 1, 2);

		// Add HBox and GridPane to BorderPane
		borderP.setTop(hbox);
		borderP.setTop(gridP);

		// Button Action
		loginBtn.setOnAction(new EventHandler() {
			@Override
			public void handle(Event event) {
				String username = textUser.getText().toString();

				cb.checkingStart(mainStage, username);

				mainStage.show();

			}
		});
		
		String image = getResource("images/Login.jpg");
		borderP.setStyle("-fx-background-image: url('" + image + "'); " + "-fx-background-position: center center; "
				+ "-fx-background-repeat: stretch:");

		scene1 = new Scene(borderP, 450, 150);
		scene1.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

		mainStage.setScene(scene1);
		mainStage.show();

	}
	
	public static String getResource(String path) {
		return Main.class.getResource(path).toExternalForm();
	}

	public static void main(String[] args) {
		launch(args);
	}

}