package application;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CheckingBase {

	private static Stage checkingBaseStage;
	private static Scene checkScene;
	private static double balance = 0;
	private static ArrayList<String> transactionList = new ArrayList<String>();

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void checkingStart(Stage primaryStage, String username) {
		Month month = new Month();
		File file = new File(username);

		checkingBaseStage = primaryStage;
		checkingBaseStage.setTitle(username + "'s Account");

		ListView<String> transactions = new ListView<String>();

		ObservableList<Month> monthList = FXCollections.observableArrayList();

		if (file.isDirectory()) {
			readFile(username, transactions);
			
		} 
		
		else {

			// Amount
			Label amountLbl = new Label("Amount: ");
			Label monthLbl = new Label("Month: ");
			Label balanceLbl = new Label("Balance: ");

			TextField amountTxt = new TextField();
			TextField monthTxt = new TextField();

			// Buttons
			Button depBtn = new Button("Deposit");
			Button withBtn = new Button("Withdraw");
			Button viewBtn = new Button("View");

			// HBox
			HBox hb = new HBox(10, amountLbl, amountTxt, monthLbl, monthTxt);
			hb.setAlignment(Pos.CENTER);
			HBox btnHB = new HBox(10, depBtn, withBtn, viewBtn);
			btnHB.setAlignment(Pos.CENTER);

			// VBox
			VBox vb = new VBox(10, hb, btnHB, balanceLbl, transactions);
			vb.setPadding(new Insets(10));
			vb.setAlignment(Pos.CENTER);

			// Events
			depBtn.setOnAction(new EventHandler() {

				@Override
				public void handle(Event event) {
					depositClick(month, amountTxt, monthTxt, transactions, monthList, username);
					balanceLbl.setText("Balance: $" + month.getBalance());
				}
			});

			withBtn.setOnAction(new EventHandler() {

				@Override
				public void handle(Event event) {
					withdrawClick(month, amountTxt, monthTxt, transactions, monthList, username);
					balanceLbl.setText("Balance: $" + month.getBalance());

				}
			});

			viewBtn.setOnAction(new EventHandler() {

				@Override
				public void handle(Event event) {
					checkingBaseStage.setTitle("Transaction Chart");
					try {
						CheckingBase.BarChartView(checkingBaseStage, monthList /* , Month month */);

					}

					catch (Exception e) {
						e.printStackTrace();
					}

				}
			});

			writeFile(username);
			
			String image = getResource("images/ATMImage.jpg");
			vb.setStyle("-fx-background-image: url('" + image + "'); " + "-fx-background-position: center center; "
					+ "-fx-background-repeat: stretch:");
			checkScene = new Scene(vb);
			checkingBaseStage.setScene(checkScene);
			checkingBaseStage.show();
		}
	}

	// Depsoit Button
	public static void depositClick(Month month, TextField amountTxt, TextField monthTxt, ListView<String> transactions,
			ObservableList<Month> monthList, String username) {

		double amount = Double.parseDouble(amountTxt.getText());
		String monthName = monthTxt.getText();

		balance += amount;

		month.setAmount(amount);
		month.setMonthName(monthName);

		amountTxt.clear();

		transactions.getItems().addAll("Deposited +$" + month.getAmount() + " in " + month.getMonthName() + ".");
		transactionList.add("Deposited +$" + month.getAmount() + " in " + month.getMonthName() + ".");
		month.depositAmount(amount);

		monthList.add(new Month(monthName, amount));
		writeFile(username);
	}

	// Withdraw Button
	public static void withdrawClick(Month month, TextField amountTxt, TextField monthTxt,
			ListView<String> transactions, ObservableList<Month> monthList, String username) {

		double amount = Double.parseDouble(amountTxt.getText());
		String monthName = monthTxt.getText();

		balance -= amount;

		month.setAmount(amount);
		month.setMonthName(monthName);

		amountTxt.clear();

		transactions.getItems().addAll("Withdrew -$" + month.getAmount() + " in " + month.getMonthName() + ".");
		transactionList.add("Withdrew -$" + month.getAmount() + " in " + month.getMonthName() + ".");
		month.withdrawAmount(amount);

		monthList.add(new Month(monthName, amount));
		writeFile(username);
	}

	// Linechart Button
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void BarChartView(Stage chartStage, ObservableList<Month> monthList /* , Month month */) {

		// Axis
		final CategoryAxis xAxis = new CategoryAxis();
		xAxis.setLabel("Months");

		final NumberAxis yAxis = new NumberAxis();
		yAxis.setLabel("Amount Change");

		// Chart
		LineChart<String, Number> lineChart = new LineChart<String, Number>(xAxis, yAxis);

		Series<String, Number> series = new Series<String, Number>();

		lineChart.setTitle("Transaction Balance: $" + balance);

		// Populating the series with data
		for (int i = 0; i < monthList.size(); i++) {

			series = new XYChart.Series<String, Number>();

			for (Month month : monthList) {

				Data<String, Number> data = new Data<String, Number>(month.getMonthName(), month.getAmount());
				series.getData().add(data);
			}

			lineChart.getData().addAll(series);
			lineChart.setLegendVisible(false);
		}

		Button backBtn = new Button("Back");

		backBtn.setOnAction(new EventHandler() {

			@Override
			public void handle(Event event) {
				checkingBaseStage.setScene(checkScene);
				checkingBaseStage.show();

			}
		});

		StackPane spChart = new StackPane();
		spChart.getChildren().add(lineChart);

		VBox vb = new VBox();
		VBox.setVgrow(spChart, Priority.ALWAYS);
		vb.getChildren().addAll(spChart, backBtn);

		Scene scene = new Scene(vb, 500, 550);

		vb.setStyle("-fx-backgroundd: #7CB9E8");
		lineChart.setStyle("-fx-background: #7CB9E8");
		chartStage.setScene(scene);
		chartStage.show();

	}

	public static void writeFile(String username) {
		File fileName = new File(username + ".txt");

		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(fileName));

			for (String str : transactionList) {

				bw.write(String.valueOf(str));
				bw.newLine();
			}

			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void readFile(String username, ListView<String> transactions) {
		File fileName = new File(username + ".txt");

		try {
			Scanner in = new Scanner(fileName);

			while (in.hasNextLine()) {

				transactions.getItems().addAll(in.nextLine());
			}

			in.close();

		} 
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String getResource(String path) {
		return Main.class.getResource(path).toExternalForm();
	}
	
	public static void main(String[] args) {

		Application.launch(args);

	}

}
