package application;

import java.util.ArrayList;

public class Month {

	private double balance;
	private double amount;

	private String monthName;
	private ArrayList<Double> amounts;

	public Month(String monthName, double amount) {
		super();
		this.monthName = monthName;
		this.amount = amount;
		// balance = 0;

		amounts = new ArrayList<Double>();
		amounts.add(amount);
	}

	public Month() {
		monthName = getMonthName();
		amount = getAmount();

	}

	public void depositAmount(double amount) {
		balance += amount;
	}

	public void withdrawAmount(double amount) {
		balance -= amount;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getMonthName() {
		return monthName;
	}

	public void setMonthName(String monthName) {
		this.monthName = monthName;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Amount: +/- $" + amount + " Month: " + monthName;
	}
	
	
}
